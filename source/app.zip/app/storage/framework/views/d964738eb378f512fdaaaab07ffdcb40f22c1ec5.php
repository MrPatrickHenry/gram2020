<?php $__env->startSection('content'); ?>
    <div class="container app">
        <div class="posts col-xs-12 col-sm-12 col-md-8 col-lg-6">
            <?php if(count($posts)): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <div class="caption">
                            <h4><?php echo e($post->caption->text); ?></h4>
                        </div>

                        <?php if($post->type === 'image'): ?>
                            <div class="image">
                                <img src="<?php echo e($post->images->standard_resolution->url); ?>" alt="">
                            </div>
                        <?php else: ?>

                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/patrickhenry/Dev/2019 Dev/gram2020/source/app/resources/views/search.blade.php ENDPATH**/ ?>