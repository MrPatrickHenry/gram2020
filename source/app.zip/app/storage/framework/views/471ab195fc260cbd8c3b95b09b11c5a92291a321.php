<?php $__env->startSection('content'); ?>
    <div class="container app">
        <?php if(Auth::user()->instagram): ?>
            <div class="profile-header">
                <div class="col-xs-12 col-sm-12 col-md-2 col-lg-2 picture">
                    <img src="<?php echo e($user->profile_picture); ?>" alt="...">
                </div>

                <div class="col-xs-12 col-sm-12 col-md-10 col-lg-10 info">
                    <h1><?php echo e($user->username); ?></h1>

                    <span>
                        Posts(<?php echo e($user->counts->media); ?>) .
                        Followers(<?php echo e($user->counts->followed_by); ?>) .
                        Following(<?php echo e($user->counts->follows); ?>)
                    </span>
                </div>
            </div>

            <div class="posts col-xs-12 col-sm-12 col-md-8 col-lg-6">
                <?php if($posts): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post">
                            <div class="caption">
                                <h4><?php echo e(isset($post->caption->text) ? $post->caption->text : ''); ?></h4>
                            </div>

                            <?php if($post->type === 'image'): ?>
                                <div class="image">
                                    <img src="<?php echo e($post->images->standard_resolution->url); ?>" alt="">
                                </div>
                            <?php else: ?>

                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    No Instagram posts
                <?php endif; ?>
            </div>
        <?php else: ?>
            <a href="/instagram" class="btn btn-default">
                Authenticate with Instagram
            </a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/app/resources/views/index.blade.php ENDPATH**/ ?>